import connexion
import six

from swagger_server import util


def get_feed_names():  # noqa: E501
    """Displays list of ingestion rules / feed names

    Displays list of ingestion rules / feed names # noqa: E501


    :rtype: Dict[str, int]
    """
    return 'do some magic!'
