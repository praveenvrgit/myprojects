import connexion
import six

from swagger_server import util


def delete_feed_names(feedname):  # noqa: E501
    """Deletes a ingestion rule

     # noqa: E501

    :param feedname: Ingestion rule to delete
    :type feedname: int

    :rtype: None
    """
    return 'do some magic!'
