import connexion
import six

from swagger_server import util


def trigger_ingestion(feedname):  # noqa: E501
    """Trigger data ingestion for a feed

     # noqa: E501

    :param feedname: Ingestion rule to trigger
    :type feedname: int

    :rtype: None
    """
    return 'do some magic!'
