import connexion
import six

from swagger_server.models.kafka import Kafka  # noqa: E501
from swagger_server import util


def create_new_ingestion_rules(body):  # noqa: E501
    """Create New rules for KAFKA data ingestion

     # noqa: E501

    :param body: New KAFKA data source to be configured
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Kafka.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
