# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.kafka import Kafka  # noqa: E501
from swagger_server.test import BaseTestCase


class TestCreateController(BaseTestCase):
    """CreateController integration test stubs"""

    def test_create_new_ingestion_rules(self):
        """Test case for create_new_ingestion_rules

        Create New rules for KAFKA data ingestion
        """
        body = Kafka()
        response = self.client.open(
            '/v2/create/kafka',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
