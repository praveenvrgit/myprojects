import connexion
import six

from swagger_server import util


def delete_feed_names(feedname):  # noqa: E501
    """Deletes a pet

     # noqa: E501

    :param feedname: Pet id to delete
    :type feedname: int

    :rtype: None
    """
    return 'do some magic!'
