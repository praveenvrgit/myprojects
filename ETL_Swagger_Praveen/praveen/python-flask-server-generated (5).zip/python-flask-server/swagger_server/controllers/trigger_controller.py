import connexion
import six

from swagger_server import util


def trigger_ingestion(feedname):  # noqa: E501
    """Trigger a data ingestion rule

     # noqa: E501

    :param feedname: Feedname for which data ingestion needs to be triggered
    :type feedname: int

    :rtype: None
    """
    return 'do some magic!'
