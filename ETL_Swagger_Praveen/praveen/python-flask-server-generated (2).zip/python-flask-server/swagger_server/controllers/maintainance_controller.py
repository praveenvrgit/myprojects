import connexion
import six

from swagger_server import util


def delete_feed_names(feedname):  # noqa: E501
    """Delete ingestion rules / feed names

    Delete list of ingestion rules / feed names # noqa: E501

    :param feedname: Feed Name that needs to executed for data ingestion
    :type feedname: str

    :rtype: Dict[str, int]
    """
    return 'do some magic!'


def get_feed_names():  # noqa: E501
    """Displays list of ingestion rules / feed names

    Displays list of ingestion rules / feed names # noqa: E501


    :rtype: Dict[str, int]
    """
    return 'do some magic!'
