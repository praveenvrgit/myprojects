import connexion
import six

from swagger_server import util


def predictive_analysis(feedname):  # noqa: E501
    """Predictive Analysis Usecase for Telcom &amp; Manufacturing industry

     # noqa: E501

    :param feedname: Feedname for which data ingestion needs to be triggered
    :type feedname: str

    :rtype: None
    """
    return 'do some magic!'
